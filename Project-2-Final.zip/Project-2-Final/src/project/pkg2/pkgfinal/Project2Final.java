/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.pkg2.pkgfinal;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mrahman1s
 */
public class Project2Final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // BST btree = new BST();
        // pass the path to the file as a parameter
        List<Employee> empList = new ArrayList();
        DataReader dr = new DataReader();
        empList = dr.readTextFile("C:\\Users\\mrahman1s\\Documents\\NetBeansProjects\\Project-2-Final\\src\\project\\pkg2\\pkgfinal\\newfile");
        BST btree = new BST();
        System.out.println("Data Displayed below:");
        for (int i = 0; i < empList.size(); i++) {
            if (i == 0) {
            } else {

                int diff = Math.abs(empList.get(i - 1).getSalary() - empList.get(i).getSalary());

                System.out.println("Next: " + empList.get(i).getSalary() + " Previous: " + empList.get(i - 1).getSalary() + " Difference: " + diff);
                btree.insert(empList.get(i));
            }
        }


        /*  Display tree  */
        System.out.print("\nPost Order : ");
        btree.postorder();
        System.out.print("\nPre Order : ");
        btree.preorder();
        System.out.print("\nIn Order : ");
        btree.inorder();

    }
}
