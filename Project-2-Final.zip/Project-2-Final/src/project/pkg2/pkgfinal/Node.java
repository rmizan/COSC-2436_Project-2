/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.pkg2.pkgfinal;

/**
 *
 * @author mrahman1s
 */
public class Node {

    Node left, right;

    Employee data;

    Node(Employee e) {
        data = e;
        left = null;
        right = null;
    }
}
