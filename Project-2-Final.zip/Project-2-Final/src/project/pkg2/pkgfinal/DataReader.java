/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.pkg2.pkgfinal;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mrahman1s
 */
public class DataReader {
      public List<Employee> readTextFile(String textFile) {
        //public List<Employee> readCSV(String csvFile) {

        String line = "";
        String splitText = ",";
        List<Employee> empData = new ArrayList();

        try (BufferedReader br = new BufferedReader(new FileReader(textFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] eachline = line.split(",");

                String name = eachline[0];
                int salary = Integer.parseInt(eachline[1]);

                Employee emp = new Employee(name, salary);
                empData.add(emp);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return empData;
    }
}
